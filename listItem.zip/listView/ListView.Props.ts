export interface ListViewProps {
    children: any[];

}